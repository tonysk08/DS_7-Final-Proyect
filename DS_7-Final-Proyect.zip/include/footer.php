<footer class="form-row">
        <div class="col-md-4 mt-auto">
                <img align="float-left" src="img/logo.png" alt="Logo" class="responsivepie" width="40" height="40">
        </div>
        <div class="col-md-4 mt-3">
                <span>Universidad Tecnológica de Panamá - Todos los derechos reservados <br>Creado por <i class="fa fa-bug"></i> MARHA <i class="fa fa-bug"></i></span>
        </div>
</footer> 